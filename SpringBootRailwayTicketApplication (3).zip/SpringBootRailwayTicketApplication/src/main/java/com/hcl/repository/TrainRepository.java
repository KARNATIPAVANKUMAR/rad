package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.model.Train;

@Repository
public interface TrainRepository extends JpaRepository<Train, Integer>{

	Train findByTrainId(int trainId);

}