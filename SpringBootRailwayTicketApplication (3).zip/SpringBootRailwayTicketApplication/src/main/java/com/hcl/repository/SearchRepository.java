package com.hcl.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcl.model.Train;

@Repository
public interface SearchRepository extends JpaRepository<Train,Integer> {
      
	
    @Query("from Train where source=:source and destination=:destination and date=:date ")
	List<Train> findAllBySourceAndDestinationAndDate(@Param ("source")String source,@Param ("destination") String destination, @Param ("date") Date date);

}