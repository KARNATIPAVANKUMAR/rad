package com.hcl.serviceimpl;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.hcl.model.User;
import com.hcl.repository.UserRepository;
import com.hcl.service.UserService;

import net.bytebuddy.utility.RandomString;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userDao;

	@Autowired
	JavaMailSender mailSender;

	public ResponseEntity<?> login(String username) {
	User user=userDao.findByUserName(username);
	if(user!=null) {
		String otp=RandomString.make(8);
		System.out.println(otp);
		
		
		MimeMessage message=mailSender.createMimeMessage();
		MimeMessageHelper helper=new MimeMessageHelper(message);
		try {
			try {
				helper.setFrom("htckanchan@gmail.com","Train Ticket");
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			helper.setTo(user.getUserEmailId());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		String subject="One-Time-Password (OTP)";
		String content="<p>Hello "+user.getUserName()+",</p>"
				+"Here is your One-Time-Password (OTP)"
				+"<p><b>"+ otp +"</b></p>";
		try {
			helper.setSubject(subject);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			helper.setText(content,true);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		user.setOtp(otp);
		userDao.save(user);
		mailSender.send(message);

	
	
	
	
	
	}
	return new ResponseEntity<>("This you user id:"+user.getUserid(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> otpValidation(int uid, String otp) {
		if(userDao.findById(uid).isPresent()) {
			User user=userDao.findById(uid).get();
			String uotp=user.getOtp();
			System.out.println(uotp);
			System.out.println(otp);
			if(otp.equals(uotp)) {
				return new ResponseEntity<>("Login success",HttpStatus.OK);
			}
		
			return new ResponseEntity<>("Invalid OTP",HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>("UserDoes Not Exit with this email id",HttpStatus.ALREADY_REPORTED);

	}
}
