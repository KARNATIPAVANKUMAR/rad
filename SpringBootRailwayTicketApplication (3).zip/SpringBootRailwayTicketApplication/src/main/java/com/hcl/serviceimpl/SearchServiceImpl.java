package com.hcl.serviceimpl;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.exception.DetailsNotFoundException;
import com.hcl.model.Train;
import com.hcl.repository.SearchRepository;
import com.hcl.service.SearchService;

@Service
@Transactional
public class SearchServiceImpl implements SearchService {
	@Autowired
	SearchRepository searchrepo;

	@Override
	public 	ResponseEntity<Map>  gettrains(String source, String destination,Date date) {
		
		Map<String,Object> response=new HashMap<>();
		
			List<Train> train=searchrepo.findAllBySourceAndDestinationAndDate(source, destination,date);
			
				response.put("message", "Search Successful");
				response.put("statuscode", HttpStatus.OK);
			    response.put("train", train);
			    if(train.size()==0) 
			    	
			    	 throw new DetailsNotFoundException("Details Not found....Please enter the correct details ");
			 
			    	
			    
			return new ResponseEntity<Map>(response,HttpStatus.OK);
		
		
	           
	}

	
}

