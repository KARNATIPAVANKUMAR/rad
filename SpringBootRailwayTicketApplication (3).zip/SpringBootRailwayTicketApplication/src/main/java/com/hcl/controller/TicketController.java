package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.exception.TicketNotBookedException;
import com.hcl.model.Booking;
import com.hcl.model.Passengers;
import com.hcl.service.TicketService;


@RestController
public class TicketController {

	 private static final Logger LOGGER = LogManager.getLogger(TicketController.class);

	@Autowired
	private TicketService ticketService;

	@PostMapping("/tickets")
	public ResponseEntity<String> bookingTicket(@RequestParam int userId, @RequestParam int trainId,
			@RequestBody List<Passengers> passengers) throws TicketNotBookedException {
		LOGGER.info(" Ticket Controller gets  started");
		return new ResponseEntity<String>(ticketService.bookingTicket(userId, trainId, passengers), HttpStatus.OK);
	}
	@GetMapping("/tickets/{userId}")
	public Optional<Booking> getBooking(@RequestParam int userId) {
		LOGGER.info("History Controller gets  started");
		return ticketService.getBooking(userId);
	}

}

