package com.hcl.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.exception.DetailsNotFoundException;
import com.hcl.model.Train;
import com.hcl.service.SearchService;

@RestController
public class SearchController {
	 private static final Logger LOGGER = LogManager.getLogger(SearchController.class);
		
	@Autowired
	SearchService searchService;
	@GetMapping("/trains")
	public ResponseEntity<Map> searchtrains( @RequestParam("source") String source,@RequestParam("destination") String destination,@RequestParam("date")Date date)  
	{	
		
		LOGGER.info("Controller gets  started");
		 return searchService.gettrains(source, destination, date);
			
		
		
		
	}
}
