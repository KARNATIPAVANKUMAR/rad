package com.hcl.exception;
public class DetailsNotFoundException extends  RuntimeException {
public DetailsNotFoundException() {
		super();
	}

public DetailsNotFoundException(String message) {
		super(message);
		this.message = message;
	}

private static final long serialVersionUID = 1L;
	
	public String message;

	
}