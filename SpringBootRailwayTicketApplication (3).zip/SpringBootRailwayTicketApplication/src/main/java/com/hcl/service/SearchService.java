package com.hcl.service;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.hcl.model.Train;

public interface SearchService {

	

	ResponseEntity<Map> gettrains(String source, String destination, Date date);

}
