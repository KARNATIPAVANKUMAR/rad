package com.hcl.service;

import java.util.List;
import java.util.Optional;

import com.hcl.exception.TicketNotBookedException;
import com.hcl.model.Booking;
import com.hcl.model.Passengers;

public interface TicketService {

	String bookingTicket(int userId, int trainId,List<Passengers> passengers) throws TicketNotBookedException;

	Optional<Booking> getBooking(int userId);

}