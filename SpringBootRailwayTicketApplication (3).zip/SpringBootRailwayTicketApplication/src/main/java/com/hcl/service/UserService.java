package com.hcl.service;
import javax.mail.MessagingException;

import org.springframework.http.ResponseEntity;

import com.hcl.model.User;

public interface UserService {
	
	public ResponseEntity<?> login(String username);
	
	public ResponseEntity<String> otpValidation(int uid,String otp);
	

}