package com.hcl.TestController;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;


import com.hcl.controller.SearchController;
import com.hcl.exception.DetailsNotFoundException;
import com.hcl.model.Train;
import com.hcl.serviceimpl.SearchServiceImpl;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness=Strictness.LENIENT)
public class SearchTestController {
	@Mock
	SearchServiceImpl service;
	@InjectMocks
	SearchController controller;
	static Train trains;
	static ResponseEntity<Map> train;
	@BeforeAll
	public static void setUp() {
		trains=new Train();
		trains.setTrainId(1);
		trains.setTrainName("Bangalore Express");
		trains.setTrainNumber(321345);
		trains.setSource("Bangalore");
		trains.setDestination("Chennai");
		trains.setSeats(345);
		trains.setCost_single_seat(321);
		trains.setDate(Date.valueOf("2021-09-21"));
		Train t=new Train(1,54643,"Bangalore Express","Bangalore","Chennai",345,321,Date.valueOf("2021-09-21"));
	
	
		
		
		
		
		
		
		
	}
	@Test
	@DisplayName("Get Products Function: Positive Scenario")
	public void loginTest() {
		
		
		
		Map<String,Object> response=new HashMap<>();
		response.put("message", "Search Successful");
		// context
		when(service.gettrains("Bangalore", "Chennai", Date.valueOf("2021-09-21"))).thenReturn(new ResponseEntity<>(response,HttpStatus.OK));

		// event
		ResponseEntity<Map> emp =controller.searchtrains("Bangalore", "Chennai", Date.valueOf("2021-09-21"));

		// outcome
		assertEquals(response, emp.getBody());

	}
	
	@Test
	@DisplayName("Get Products Function: Positive Scenario")
	public void loginTestnegative() {
		
		ResponseEntity<Map> trainlist=service.gettrains("Bangalore", "Chennai", Date.valueOf("2021-09-21"));
		
		Map<String,Object> response=new HashMap<>();
		 response.put("train", trainlist);
		// context
		when(service.gettrains("Bangalore", "Chennai", Date.valueOf("2021-09-21"))).thenReturn(new ResponseEntity<>(response,HttpStatus.OK));

		// event
		ResponseEntity<Map> emp =controller.searchtrains("Bangalore", "Chennai", Date.valueOf("2021-09-21"));

		// outcome
		assertEquals(response,emp.getBody());

	}
	@Test
	@DisplayName("Get Function: Negative Scenario")
	public void loginTest2() {
		ResponseEntity<Map> trainlist=service.gettrains("Tirpur", "Chennai", Date.valueOf("2021-09-21"));
		//context
		when(service.gettrains("Tirpur", "Chennai", Date.valueOf("2021-09-21"))).thenThrow(DetailsNotFoundException.class);
		
		//event
		//outcome
		assertThrows(DetailsNotFoundException.class, ()->controller.searchtrains("Tirpur", "Chennai", Date.valueOf("2021-09-21")));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
