package com.hcl.TestController;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.hcl.controller.TicketController;
import com.hcl.exception.TicketNotBookedException;
import com.hcl.model.Booking;
import com.hcl.model.Passengers;
import com.hcl.model.Train;
import com.hcl.model.User;
import com.hcl.serviceimpl.TicketServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TicketControllerTest {

	@Mock
	TicketServiceImpl ticketService;

	@InjectMocks
	TicketController ticketController;

	static Passengers passengers;
	static List<Passengers> passengersList;
	static User user;
	static Booking booking;
	static Train train;

	@BeforeAll
	public static void setup() {

		booking = new Booking();
		booking.setBookingId(1);
		booking.setDate(new Date());
		booking.setPassengers(passengersList);
		booking.setPrice_total(400);
		booking.setTrain(train);
		booking.setUser(user);

		train = new Train();
		train.setCost_single_seat(100);
		train.setDestination("hyderabad");
		train.setSeats(5);
		train.setSource("Nellore");
		train.setTrainId(1);
		train.setTrainName("HyderabadExpress");
		train.setTrainNumber(1234);

		user = new User();
		user.setUserid(1);
		user.setUserName("Radhika");

		passengers = new Passengers();
		passengers.setAddress("nellore");
		passengers.setAdhaarNumber(3478975436787L);
		passengers.setAge(24);
		passengers.setGender("female");
		passengers.setName("radhika");

		// passengersList.add(passengers);
	}

	@Test
	@DisplayName("Ticket booking: positive scenerio")
	public void addBookingTest() throws TicketNotBookedException {

		when(ticketService.bookingTicket(1, 1, passengersList)).thenReturn("Ticket booked successfully");

		ResponseEntity<String> result = ticketController.bookingTicket(1, 1, passengersList);

		assertEquals("Ticket booked successfully", result.getBody());

	}

	@Test
	@DisplayName("Ticket booking: negative scenerio")
	public void addBookingTest1() throws TicketNotBookedException {

		when(ticketService.bookingTicket(1, 1, passengersList)).thenThrow(TicketNotBookedException.class);

		assertThrows(TicketNotBookedException.class, () -> ticketController.bookingTicket(1, 1, passengersList));

	}
}