package com.hcl.SearchTestService;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.hcl.exception.TicketNotBookedException;
import com.hcl.model.Booking;
import com.hcl.model.Passengers;
import com.hcl.model.Train;
import com.hcl.model.User;
import com.hcl.repository.TicketRepository;
import com.hcl.repository.TrainRepository;
import com.hcl.repository.UserRepository;
import com.hcl.serviceimpl.TicketServiceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class TicketServiceImplTest {

	@InjectMocks
	TicketServiceImpl ticketServiceImpl;

	@Mock
	TicketRepository ticketRepository;

	@Mock
	UserRepository userRepository;

	@Mock
	TrainRepository trainRepository;

	static Passengers passengers;
	static List<Passengers> passengersList;
	static User user;
	static Booking booking;
	static Train train;

	@BeforeAll
	public static void setup() {

		train = new Train();
		train.setCost_single_seat(100);
		train.setDestination("hyderabad");
		train.setSeats(5);
		train.setSource("Nellore");
		train.setTrainId(1);
		train.setTrainName("HyderabadExpress");
		train.setTrainNumber(1234);

		user = new User();
		user.setUserid(1);
		user.setUserName("Radhika");

		passengers = new Passengers();
		passengers.setAddress("nellore");
		passengers.setAdhaarNumber(3478975436787L);
		passengers.setAge(24);
		passengers.setGender("female");
		passengers.setName("radhika");

		passengersList = new ArrayList<Passengers>();
		passengersList.add(passengers);

		booking = new Booking();
		booking.setBookingId(1);
		booking.setDate(new Date());
		booking.setPassengers(passengersList);
		booking.setPrice_total(400);
		booking.setTrain(train);
		booking.setUser(user);

	}

	@Test
	@DisplayName("Ticket Booking:Positive Scenario")
	public void bookingTicketTest() throws TicketNotBookedException {
		// when(userRepository.existsById(1)).thenReturn(true);
		// when(trainRepository.existsById(1)).thenReturn(true);

		when(userRepository.findByUserid(1)).thenReturn(user);
		when(trainRepository.findByTrainId(1)).thenReturn(train);

		when(ticketRepository.save(any(Booking.class))).thenAnswer(i -> {
			Booking booking = i.getArgument(0);
			return booking;
		});

		String result = ticketServiceImpl.bookingTicket(1, 1, passengersList);

		assertEquals("Ticket booked successfully", result);

	}

	@Test
	@DisplayName("Ticket Booking:Negative Sceranio")
	public void bookinTicketTest2() throws TicketNotBookedException {

		// context
		when(userRepository.findByUserid(1)).thenReturn(null);
		when(trainRepository.findByTrainId(1)).thenReturn(null);

		// event and outcome
		assertThrows(TicketNotBookedException.class, () -> ticketServiceImpl.bookingTicket(1, 1, passengersList));

	}

}