package com.hcl.SearchTestService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hcl.exception.DetailsNotFoundException;
import com.hcl.model.Train;
import com.hcl.repository.SearchRepository;
import com.hcl.service.SearchService;
import com.hcl.serviceimpl.SearchServiceImpl;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness=Strictness.LENIENT)
public class SearchServiceTest {
	@Mock
	SearchRepository repo;
	@InjectMocks
	SearchServiceImpl service;
	static List<Train> trains;
	@BeforeAll
	public static void setUp() {
		trains=new ArrayList<Train>();
		Train t=new Train(1,54643,"Bangalore Express","Bangalore","Chennai",345,321,Date.valueOf("2021-09-21"));
		trains.add(t);
		
	}
	
	
	
	
	@Test
	@DisplayName("Get Products Function: Negative Scenario")
	public void loginTestnegatives() {
		// context
				when(repo.findAllBySourceAndDestinationAndDate("Bangalore", "chennai", Date.valueOf("2021-09-21"))).thenReturn(trains);
				// event
				List<Train> tr=repo.findAllBySourceAndDestinationAndDate("Tirupur", "chennai", Date.valueOf("2021-09-21"));
				// outcome
				assertNotEquals(tr,trains);
	}
	@Test
	@DisplayName("Get Search Function: Positive Scenario")
	public void loginTest() {
		// context
				when(repo.findAllBySourceAndDestinationAndDate("Bangalore", "chennai", Date.valueOf("2021-09-21"))).thenReturn(trains);
				// event
				List<Train> tr=repo.findAllBySourceAndDestinationAndDate("Bangalore", "chennai", Date.valueOf("2021-09-21"));
				// outcome
				assertSame(tr,trains);
	}
	@Test
	@DisplayName("Get Function: Negative Scenario")
	public void loginTest2() {
		
		//context
		when(repo.findAllBySourceAndDestinationAndDate("Tirpur", "Chennai", Date.valueOf("2021-09-21"))).thenThrow(DetailsNotFoundException.class);
		
		//event
		//outcome
		assertThrows(DetailsNotFoundException.class, ()->service.gettrains("Tirpur", "Chennai", Date.valueOf("2021-09-21")));
	}
	
	
	
	
	
	
	
	
	
}
